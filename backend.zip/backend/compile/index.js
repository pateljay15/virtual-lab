const express = require("express")
const app = express()
const bodyParser = require('body-parser')
const cookieParser = require('cookie-parser')
const cors = require('cors');


// app.use(bodyParser.urlencoded({ extended: true }))
// app.use(bodyParser.json())
// app.use(cookieParser())

// app.use(
//     cors({
//        allowedHeaders: ['sessionId', 'Content-Type'],
//        exposedHeaders: ['sessionId'],
//        origin: '*',
//        methods: 'GET,HEAD,PUT,PATCH,POST,DELETE',
//        preflightContinue: false,
//     })
//  );

 const axios = require("axios");

var qs = require('qs');
var data = qs.stringify({
    // 'code': 'val = int(input("Enter your value: ")) + 5\nprint(val)',
    'code': 'print("hello World")',
    'language': 'py',
    // 'input': '7'
});
var config = {
    method: 'post',
    url: 'https://api.codex.jaagrav.in',
    headers: {
        'Content-Type': 'application/x-www-form-urlencoded'
    },
    data : data
};

axios(config)
  .then(function (response) {
    console.log(JSON.stringify(response.data));
  })
  .catch(function (error) {
    console.log(error);
  });

// const encodedParams = new URLSearchParams();
// encodedParams.append("code", "print(\"Hello World!\")");
// encodedParams.append("language", "py");

// const options = {
//   method: 'POST',
//   url: 'https://codex7.p.rapidapi.com/',
//   headers: {
//     'content-type': 'application/x-www-form-urlencoded',
//     'X-RapidAPI-Key': 'c5d2ec3197msh47d346a0e8ff853p128061jsnafdfb3cd3b16',
//     'X-RapidAPI-Host': 'codex7.p.rapidapi.com'
//   },
//   data: encodedParams
// };

// axios.request(options).then(function (response) {
// 	console.log(response.data);
// }).catch(function (error) {
// 	console.error(error);
// });