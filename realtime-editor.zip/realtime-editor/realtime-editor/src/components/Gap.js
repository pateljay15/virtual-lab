import React, { useState, useEffect } from 'react';
import { NavLink, Outlet } from 'react-router-dom';
import '../Styles/Gap.css';

function Gap() {

    return (
        <div className="content_gap">

        </div >
    );
}

export default Gap;